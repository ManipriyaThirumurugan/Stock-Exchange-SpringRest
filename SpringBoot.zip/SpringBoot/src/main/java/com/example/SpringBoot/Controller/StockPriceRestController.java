package com.example.SpringBoot.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.example.SpringBoot.Dao.StockPriceDao;
import com.example.SpringBoot.Model.StockPrice;


@RestController
public class StockPriceRestController {

	@Autowired
	StockPriceDao stockPriceDao;

	@GetMapping(value = "/stockPriceDetailsByCompanyId/{companyCode}")
	public List<StockPrice> SectorList(@PathVariable("companyCode") Integer companyCode) {

		List<StockPrice> stockPriceDetails = stockPriceDao.findBycompanyCode(companyCode);
		return stockPriceDetails;
	}
}
